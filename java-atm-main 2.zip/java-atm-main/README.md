# java-atm
Java Example of ATM 
_______
<br>POM created with
> mvn archetype:generate 
> 
> -DarchetypeGroupId=org.apache.maven.archetypes 
> 
> -DarchetypeArtifactId=maven-archetype-quickstart 
> 
> -DarchetypeVersion=1.4
_______
<br>
Notice the follow components in the solution
<br>

* Pseudocode
* Pakages, Classes, Methods
* Config File
* Unit Tests

_______
<br>
Coverage

<img width="643" alt="image" src="https://user-images.githubusercontent.com/53359912/212460772-b9e2b248-f696-44f4-88b9-ec43b9a5278e.png">


![image](https://user-images.githubusercontent.com/53359912/212450776-9072047f-5ff5-44d7-b559-3defeaa9fbb9.png)

![image](https://user-images.githubusercontent.com/53359912/212450812-90229090-9e21-4e47-8b45-b398330bd04b.png)
