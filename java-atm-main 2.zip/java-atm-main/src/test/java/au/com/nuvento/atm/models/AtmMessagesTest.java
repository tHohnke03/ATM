package au.com.nuvento.atm.models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AtmMessagesTest {



    @Test
    void getAction() {
        assertEquals(AtmMessages.AMOUNT.getAction(),"..... Please enter the amount ..... ");
        assertEquals(AtmMessages.WELCOME.getAction(),"Welcome to your ATM .......");
        assertEquals(AtmMessages.EXIT.getAction(),"Thank you. Exiting ATM .......");
        assertEquals(AtmMessages.ERROR.getAction(),"..... Error your details are incorrect ..... ");
        assertEquals(AtmMessages.NUMERIC.getAction(),"..... Sorry that amount is not valid ..... ");

    }

    @Test
    void values() {
        assertEquals(AtmMessages.values().length,8);
    }

    @Test
    void valueOf() {
        assertEquals(AtmMessages.valueOf("AMOUNT"),AtmMessages.AMOUNT);
    }
}