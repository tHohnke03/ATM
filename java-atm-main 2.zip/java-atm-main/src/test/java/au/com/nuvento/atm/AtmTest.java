package au.com.nuvento.atm;

import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AtmTest {

    @Test
    public void givenATMSetupRunAccountsWillBeCreated() throws FileNotFoundException {
        Atm.setup();

        assertEquals(Atm.accounts.size(), 5);
    }


}
