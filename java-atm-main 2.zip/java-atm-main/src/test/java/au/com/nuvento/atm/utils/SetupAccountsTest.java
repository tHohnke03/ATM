package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.accounts.Account;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SetupAccountsTest {

    ReadFiles readFiles;
    String ACCOUNT_DATA;
    String USER_INFO;
    String ACCOUNT_DATA_DELIM;
    String USER_INFO_DELIM;

    SetupAccounts setupAccounts;
    List<String[]> accountData;

    @BeforeEach
    public void setup()  throws FileNotFoundException{
        readFiles = new ReadFiles();
        ACCOUNT_DATA = "data/OpeningAccountsData.txt";
        ACCOUNT_DATA_DELIM = "\\|\\|\\|";
        setupAccounts = new SetupAccounts();
        accountData = readFiles.getCSVFileContents(ACCOUNT_DATA, ACCOUNT_DATA_DELIM, true);

    }

    @Test
    public void givenOpeningAccountsDataThenCreateAccountObjects() throws FileNotFoundException {
        accountData = readFiles.getCSVFileContents(ACCOUNT_DATA, ACCOUNT_DATA_DELIM, true);
        HashMap<String,Account> accounts = setupAccounts.createAccounts(accountData);
        assertEquals(accounts.size(), 5);
    }

    @Test
    public void whenCreateAccountObjectsReturnedAccountHolderId() throws FileNotFoundException {
        List<String[]> accountData = readFiles.getCSVFileContents(ACCOUNT_DATA, ACCOUNT_DATA_DELIM, true);
        HashMap<String,Account> accounts = setupAccounts.createAccounts(accountData);
        assertEquals(accounts.get("9264945").getAccountHolderId(),"001");
        assertEquals(accounts.get("9676422").getAccountHolderId(),"002");
    }
}
