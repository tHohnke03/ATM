package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.Atm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ValidationTest {


    @BeforeEach
    public void setup() throws FileNotFoundException {
        Atm.setup();
    }

    @Test
    public void givenAtmSetupRunValidateUsers() throws FileNotFoundException {
        assertTrue(Validation.isUser("001", Atm.clients));
        assertTrue(Validation.isUser("003", Atm.clients));
        assertFalse(Validation.isUser("0088", Atm.clients));
    }

    @Test
    public void givenAtmSetupRunValidateAccounts() throws FileNotFoundException {
        assertTrue(Validation.isAccount("001", "9264945", Atm.accounts));
        assertTrue(Validation.isAccount("003", "9042221", Atm.accounts));
        assertFalse(Validation.isAccount("002", "9676421", Atm.accounts));
        assertFalse(Validation.isAccount("003", "9264945", Atm.accounts));
    }

    @Test
    public void givenStringReturnTrueIfNumeric() throws FileNotFoundException {
        assertTrue(Validation.isNumeric("7"));
        assertTrue(Validation.isNumeric("20.98"));
        assertFalse(Validation.isNumeric("a0088"));
    }
}
