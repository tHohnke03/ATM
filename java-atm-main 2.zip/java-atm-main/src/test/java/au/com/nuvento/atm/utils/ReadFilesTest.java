package au.com.nuvento.atm.utils;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ReadFilesTest {

    ReadFiles readFiles;
    String ACCOUNT_DATA;
    String USER_INFO;
    String ACCOUNT_DATA_DELIM;
    String USER_INFO_DELIM;

    @BeforeEach
    public void setup() {
        readFiles = new ReadFiles();
        ACCOUNT_DATA = "data/OpeningAccountsData.txt";
        USER_INFO = "data/UserInfo.txt";
        ACCOUNT_DATA_DELIM = "\\|\\|\\|";
        USER_INFO_DELIM = ",";
    }

    @Test
    public void givenOpeningAccountsDataThenCountItemsReturned() throws FileNotFoundException {
        List<String[]> accountData = readFiles.getCSVFileContents(ACCOUNT_DATA, ACCOUNT_DATA_DELIM, true);

        assertEquals(accountData.size(), 5);
        assertEquals(accountData.get(0).length,4);
        assertEquals(accountData.get(3).length,4);

    }

    @Test
    public void givenUserInfoDataThenCountItemsReturned() throws FileNotFoundException {
        List<String[]> userInfo = readFiles.getCSVFileContents(USER_INFO, USER_INFO_DELIM, true);

        assertEquals(userInfo.size(), 3);
        //assertEquals(userInfo.get(0).length,4);
        //assertEquals(userInfo.get(3).length,4);

    }
}
