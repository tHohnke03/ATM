package au.com.nuvento.atm.accounts;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccountTypeTest {

    @Test
    void values() {
        assertEquals(AccountType.values().length,2);
    }

    @Test
    void valueOf() {
        assertEquals(AccountType.valueOf("SAVING"),AccountType.SAVING);
    }
}