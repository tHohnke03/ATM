package au.com.nuvento.atm.models;

import au.com.nuvento.atm.Atm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ClientInteractionTest {

    ClientInteraction clientInteraction;

    @BeforeEach
    public void setup()  throws FileNotFoundException{
        clientInteraction = new ClientInteraction();
        Atm.setup();
    }

    @Test
    public void givenATMSetupRunDepositWillRun() throws FileNotFoundException {
        double amt = clientInteraction.deposit("300", Atm.accounts.get("9676422"), "001");
        assertEquals(amt, 1500);
    }

    @Test
    public void givenATMSetupRunWithdrawltWillRun() throws FileNotFoundException {
        double amt = clientInteraction.withdraw("300", Atm.accounts.get("9676422"), "001");
        assertEquals(amt, 900);
    }

}
