package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.models.Client;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SetupUsersTest {

    ReadFiles readFiles;
    String USER_INFO;
    String USER_INFO_DELIM;

    SetupUsers setupUsers;
    List<String[]> userData;

    @BeforeEach
    public void setup()  throws FileNotFoundException {
        readFiles = new ReadFiles();
        USER_INFO = "data/UserInfo.txt";
        USER_INFO_DELIM = ",";
        setupUsers = new SetupUsers();
        userData = readFiles.getCSVFileContents(USER_INFO, USER_INFO_DELIM, true);

    }

    @Test
    public void givenOpeningUsersDataThenCreateAccountObjects() throws FileNotFoundException {
        userData = readFiles.getCSVFileContents(USER_INFO, USER_INFO_DELIM, true);
        HashMap<String, Client> users = setupUsers.createUsers(userData);
        assertEquals(users.size(), 3);
    }
}
