package au.com.nuvento.atm.accounts;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccountTest {

    Account account;
    @BeforeEach
    void setUp() {
        account = new Account("100", "2468", 200000);
        account.setAccountType(AccountType.SAVING);
    }

    @Test
    void getBalance() {
        assertEquals(account.getBalance(), 200000.00);
    }

    @Test
    void setBalance() {
        account.setBalance(2);
        assertEquals(account.getBalance(), 200002.00);
    }

    @Test
    void getAccountID() {
        assertEquals(account.getAccountID(), "2468");
    }

    @Test
    void setAccountID() {
        account.setAccountID("hhh1");
        assertEquals(account.getAccountID(), "hhh1");
    }

    @Test
    void getAccountHolderId() {
        assertEquals(account.getAccountHolderId(), "100");
    }

    @Test
    void setAccountHolderId() {
        account.setAccountHolderId("1001");
        assertEquals(account.getAccountHolderId(), "1001");
    }

    @Test
    void getAccountType() {

        assertEquals(account.getAccountType(), AccountType.SAVING);
    }

    @Test
    void setAccountType() {
        account.setAccountType(AccountType.CHEQUE);
        assertEquals(account.getAccountType(), AccountType.CHEQUE);
    }

    @Test
    void testToString() {
        assertEquals(account.toString(),"100|||2468|||SAVING|||200000.0");
    }
}