package au.com.nuvento.atm.models;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {

    Client client;
    @BeforeEach
    void setUp() {
        client = new Client("david","sheard","1234567", "001");
    }

    @Test
    void getFirstName() {
        assertTrue(client.getFirstName().equalsIgnoreCase("david"));
    }

    @Test
    void setFirstName() {
        client.setFirstName("peter");
        assertTrue(client.getFirstName().equalsIgnoreCase("peter"));
    }

    @Test
    void getSurname() {
        assertTrue(client.getSurname().equalsIgnoreCase("sheard"));
    }

    @Test
    void setSurname() {
        client.setSurname("vanderslik");
        assertTrue(client.getSurname().equalsIgnoreCase("vanderslik"));
    }

    @Test
    void getMobile() {
        assertTrue(client.getMobile().equalsIgnoreCase("1234567"));
    }

    @Test
    void setMobile() {
        client.setMobile("777");
        assertTrue(client.getMobile().equalsIgnoreCase("777"));
    }

    @Test
    void getAccountOwnerID() {
        assertTrue(client.getAccountOwnerID().equalsIgnoreCase("001"));
    }

    @Test
    void setAccountOwnerID() {
        client.setAccountOwnerID("008");
        assertTrue(client.getAccountOwnerID().equalsIgnoreCase("008"));
    }
}