package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.Atm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class WriteFilesTest {

    //writeFiles(HashMap<String, Account> accounts, String outputPath,
    //String header)
    String testFile = "src/test/resources/dummy.txt";
    @BeforeEach
    public void setup() throws FileNotFoundException {
        Atm.setup();

    }

    @Test
    @DisplayName("Should create a file on a file system")
    public void givenUnixSystem_whenCreatingFile_thenCreatedInPath() {
        WriteFiles mockedWriteFiles = mock(WriteFiles.class);

        verify(mockedWriteFiles).writeFiles(Atm.accounts, testFile,
                Atm.conf.getString("HEADER"));
    }
}
