package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.models.Client;

import java.util.HashMap;
import java.util.List;

/**
 * The class to set up Clients
 */
public class SetupUsers {
    public Client createUser(String[] userInfo){
        HashMap<String,Client> clients = new HashMap<String,Client>();
        if (userInfo.length == 4) {
            return new Client(userInfo[0], userInfo[1], userInfo[2], userInfo[3]);
        }
        return null;

    }

    /**
     * A method to create Users
     * @param userInfo User data read from file and passed as List
     * @return A HashMap with Clients(Users) and Client ID as key
     */
    public HashMap<String,Client>  createUsers(List<String[]> userInfo) {
        HashMap<String,Client> clients = new HashMap<String,Client>();
        userInfo.stream().forEach(x -> {
            Client u = createUser(x);
            clients.put(u.getAccountOwnerID(),u);
        });
        return clients;

    }
}
