package au.com.nuvento.atm.models;

import au.com.nuvento.atm.accounts.Account;
import au.com.nuvento.atm.utils.Validation;

import java.util.HashMap;
import java.util.Scanner;

/**
 * Class to Handle the Client Interactions
 * After ATM.scala this i the primary class
 *
 */
public class ClientInteraction {

    Scanner sc = new Scanner(System.in);

    /**
     * This method handles the common interaction for
     * both withdralw and deposit methods
     * @param user The Client ID
     * @param accounts HashMap of Accounts
     * @param interactionType The type - withdraw, balance, deposit
     * @return The amount
     */
    public double getCommon(String user,HashMap<String,Account> accounts, String interactionType) {
        System.out.println(AtmMessages.ACCOUNTPROMPT.getAction());
        String accountNum = sc.next().trim();
        double amtNow=0;
        if(Validation.isAccount(user,accountNum,accounts)){
            Account depAccount = accounts.get(accountNum);
            System.out.println("Current Balance = " + depAccount.getBalance());
            System.out.println(AtmMessages.AMOUNT.getAction());
            String amt = sc.next().trim();
            if(Validation.isNumeric(amt)){
                if(interactionType.equalsIgnoreCase("deposit")) {
                    amtNow = deposit(amt, depAccount, accountNum);
                } else {
                    amtNow = withdraw(amt, depAccount, accountNum);
                }
            } else if(interactionType.equalsIgnoreCase("withdrawl")) {
                System.out.println(AtmMessages.NUMERIC.getAction() + "\n");
            } else {
                System.out.println(".... System Error -  Please start again ....");
            }
        } else {
            System.out.println(AtmMessages.ERROR.getAction());
        }
        return amtNow;
    }

    /**
     * This method handles the deposit function of ATM
     * @param amt A String representing the amount
     * @param account The Account
     * @param accountNum The Account Number
     * @return A double for the amount
     */
    public double deposit(String amt,Account account, String accountNum) {
        double amtEntered = Double.parseDouble(amt);
        account.setBalance(amtEntered);
        System.out.println("Deposited $" + amtEntered + " into account " + accountNum + "\n");
        System.out.println("New Balance = $" + account.getBalance() +  "\n");
        return account.getBalance();
    }

    /**
     * This method handles the balance function of ATM
     * @param user The Client ID
     * @param accounts  HashMap of Accounts
     * @return A double for the amount
     */
    public double balance(String user,HashMap<String,Account> accounts) {
        double amt = 0;
        System.out.println(AtmMessages.ACCOUNTPROMPT.getAction());
        String accountNum = sc.next().trim();

        if(Validation.isAccount(user,accountNum,accounts)){
            Account depAccount = accounts.get(accountNum);
            amt = depAccount.getBalance();
            System.out.println("Balance = $" + amt + "\n");
        }
        return amt;
    }

    /**
     * Ths class handles the withdraml function of ATM app
     * @param amt A String representing the amount
     * @param account The Account
     * @param accountNum The Account Number
     * @return A double that is the amount
     */
    public double withdraw(String amt,Account account, String accountNum) {
        double amtEntered = Double.parseDouble(amt);
        double withdrawlAmt = amtEntered-amtEntered-amtEntered;
        if(account.getBalance() >= amtEntered) {
            account.setBalance(withdrawlAmt);
            System.out.println("Withdraw $" + withdrawlAmt + " from account " + accountNum + "\n");
            System.out.println("New Balance = $" + account.getBalance() +  "\n");
        } else {
            System.out.println("Not enough funds to Withdraw $" + amtEntered + " from account " + accountNum + "\n");
            System.out.println("Current Balance = $" + account.getBalance() +  "\n");
        }
        return account.getBalance();
    }

    /**
     *
     * This method takes in two HashMaps and drive the client interactions for this class
     * @param clients HashMap of Clients
     * @param accounts HashMap of Accounts
     */
    public void run(HashMap<String,Client> clients, HashMap<String,Account> accounts) {
        String enteredOption = "";
        System.out.println(AtmMessages.INTIAL.getAction());
        enteredOption = sc.next().trim();
        String user = enteredOption;

        while(!Validation.isUser(user, clients)) {
            System.out.println(AtmMessages.ERROR.getAction());
            System.out.println(AtmMessages.INTIAL.getAction());
            user = sc.next();
        }

        System.out.println(AtmMessages.WELCOME.getAction());
        while (!enteredOption.equalsIgnoreCase("q")) {
            System.out.println(AtmMessages.OPTIONS.getAction());
            enteredOption = sc.next();

            switch(enteredOption.toLowerCase()) {
                case "1":
                    getCommon(user,accounts, "deposit");
                    break;
                case "2":
                    getCommon(user,accounts, "withdrawl");
                    break;
                case "3":
                    balance(user,accounts);
                    break;

            }

        }

    }
}
