package au.com.nuvento.atm.accounts;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Account {
    double balance;
    String accountID;
    String accountHolderId;
    AccountType accountType;
    private static final DecimalFormat df = new DecimalFormat("0.00");

    public Account(String accountHolderId, String accountID, double balance) {
        this.balance = balance;
        this.accountID = accountID;
        this.accountHolderId = accountHolderId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        df.setRoundingMode(RoundingMode.DOWN);
        double newAmt = Double.parseDouble(df.format(this.balance += balance));
        this.balance = newAmt;
    }

    public String getAccountID() {
        return accountID;
    }

    public void setAccountID(String accountID) {
        this.accountID = accountID;
    }

    public String getAccountHolderId() {
        return accountHolderId;
    }

    public void setAccountHolderId(String accountHolderId) {
        this.accountHolderId = accountHolderId;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return getAccountHolderId() + "|||" + getAccountID() + "|||" +
                getAccountType() + "|||" + getBalance();
    }
}
