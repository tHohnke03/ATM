package au.com.nuvento.atm.utils;

import java.io.*;
import java.util.*;
import java.util.List;

/**
 * A class for Reading Files
 */
public class ReadFiles {

    /**
     * Method to get CSV Contents
     *
     * @param filePath Path to the CSV file
     * @param comma_delim Variable is for delimiter
     * @param removeFirstRow Ignore header Yes/No
     * @return A List of String. Each row in File is an element in the List
     * @throws FileNotFoundException Thrown if file not in path
     */
     public List<String[]>  getCSVFileContents(String filePath, String comma_delim, boolean removeFirstRow) throws FileNotFoundException {

         List<String[]> records = new ArrayList<>();
         try (Scanner scanner = new Scanner(new File(filePath));) {
             while (scanner.hasNextLine()) {
                 records.add(scanner.nextLine().split(comma_delim));
             }
         }
         // Remove the First row
         if(removeFirstRow) records.remove(0);
         return records;
     }

}
