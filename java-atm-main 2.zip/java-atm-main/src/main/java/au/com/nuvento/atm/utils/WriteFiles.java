package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.accounts.Account;

import java.io.FileWriter;
import java.util.HashMap;

/**
 * A class to write back to Files
 */
public class WriteFiles {

    /**
     * A method that writes the File
     * @param accounts A HashMap of Accounts
     * @param outputPath PAth to write the File
     * @param header The Header
     * @return boolean
     */
    public static boolean writeFiles(HashMap<String, Account> accounts, String outputPath,
                                  String header){
        try {
            FileWriter writer = new FileWriter(outputPath);
            writer.write(header+"\n");
            for(Account acc:accounts.values()){
                writer.append(acc.toString()+"\n");
            }

            writer.close();
            System.out.println("Account file updated succesfully.");
            return true;
        } catch (Exception e) {
            System.out.println("exception :" + e.getMessage());
            return false;
        }
    }


}
