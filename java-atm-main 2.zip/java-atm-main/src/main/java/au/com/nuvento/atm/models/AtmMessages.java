package au.com.nuvento.atm.models;

/**
 * An enum for the messages provided by
 * the Client Interactions
 */
enum AtmMessages {

    INTIAL("Welcome Please\n" +
            "Enter your ID"),
    WELCOME("Welcome to your ATM ......."),
    OPTIONS("Please Enter one of the following\n" +
            "1 for Deposit\n" +
            "2 for WithDrawl\n" +
            "3 for Balance\n" +
            "q to Quit\n"),
    EXIT("Thank you. Exiting ATM ......."),
    ERROR("..... Error your details are incorrect ..... "),
    ACCOUNTPROMPT("..... Please enter your account number ..... "),

    NUMERIC("..... Sorry that amount is not valid ..... "),

    AMOUNT("..... Please enter the amount ..... ");
    private String action;

    public String getAction()
    {
        return this.action;
    }

    // enum constructor - cannot be public or protected
    private AtmMessages(String action)
    {
        this.action = action;
    }

}
