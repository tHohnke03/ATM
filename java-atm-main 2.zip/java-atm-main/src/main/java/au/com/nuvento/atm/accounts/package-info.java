/**
 * This module holds Account Obejcts and Types
 * <p>
 * This module supplys Account types and an Enum for the same
 * These Objects represent Bank Accounts
 * </p>
 *
 * @since 0.1
 * @author sheard
 * @version 1.0
 */
package au.com.nuvento.atm.accounts;