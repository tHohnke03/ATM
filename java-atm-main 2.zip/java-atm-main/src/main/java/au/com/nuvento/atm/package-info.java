/**
 * This is the entry module
 * <p>
 * This module contains the main method in App
 * </p>
 *
 * @since 0.1
 * @author sheard
 * @version 1.0
 */
package au.com.nuvento.atm;