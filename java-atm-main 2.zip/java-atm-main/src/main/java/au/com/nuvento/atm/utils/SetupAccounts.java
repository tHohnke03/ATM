package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.accounts.Account;
import au.com.nuvento.atm.accounts.AccountType;

import java.util.HashMap;
import java.util.List;

/**
 *
 * The class to set up Bank Accounts for Users
 *
 */
public class SetupAccounts {

    /**
     * A method to create Bank Accounts
     * @param accountInfo The account info read in from the csv file
     * @return A HashMap with Accounts and Account number as key
     *
     */
    public HashMap<String,Account> createAccounts(List<String[]> accountInfo) {

        HashMap<String,Account> accounts = new HashMap<String,Account>();
        accountInfo.stream().forEach(x -> {
            if(x.length == 4) {
                String accountId = x[1].trim();
                Account account = new Account(x[0].trim(),accountId,Double.parseDouble(x[3].trim()));
                String type = x[2].toLowerCase();
                switch(type) {
                    case "cheque":
                        account.setAccountType(AccountType.CHEQUE);
                        break;
                    case "saving":
                        account.setAccountType(AccountType.SAVING);
                        break;
                    default:
                        account.setAccountType(AccountType.SAVING);
                }
                accounts.put(accountId,account);
            }
        });
        return accounts;

    }
}
