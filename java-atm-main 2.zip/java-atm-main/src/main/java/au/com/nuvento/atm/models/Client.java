package au.com.nuvento.atm.models;

/**
 * Client Object
 * Represents a Client/User
 *
 */
public class Client {
    String FirstName;
    String Surname;
    String Mobile;
    String AccountOwnerID;

    /**
     * This is the default Constructor
     */
    public Client( ) { }

    /**
     * Constructor that takes all values
     * @param firstName A String representing a Client first name
     * @param surname A String representing a Client surname
     * @param mobile A String representing a Client's mobile number
     * @param accountOwnerID A String representing an Account Owner ID
     */
    public Client(String firstName, String surname, String mobile, String accountOwnerID) {
        FirstName = firstName;
        Surname = surname;
        Mobile = mobile;
        AccountOwnerID = accountOwnerID;
    }


    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getAccountOwnerID() {
        return AccountOwnerID;
    }

    public void setAccountOwnerID(String accountOwnerID) {
        AccountOwnerID = accountOwnerID;
    }
}
