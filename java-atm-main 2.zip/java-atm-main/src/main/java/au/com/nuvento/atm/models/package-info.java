/**
 * This module has Objects that Model the Client and the interface
 * <p>
 * This module has Objects that Model the Client, the Client Interactions
 * as well as the Messages used by the Client Interface
 * </p>
 *
 * @since 0.1
 * @author sheard
 * @version 1.0
 */
package au.com.nuvento.atm.models;