package au.com.nuvento.atm.utils;

import au.com.nuvento.atm.accounts.Account;
import au.com.nuvento.atm.models.Client;
import org.apache.commons.lang3.math.NumberUtils;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A class to Validate accounts, clients, and inputs
 */
public class Validation {

    /**
     * Check is valid Client
     * @param id Client ID
     * @param clients List of Clients
     * @return boolean
     */
    public static boolean isUser(String id, HashMap<String,Client> clients) {
        AtomicBoolean isFound = new AtomicBoolean(false);

        if(clients.containsKey(id)) {
            isFound.set(true);
        }
        return isFound.get();
    }

    /**
     * Check is valid Number
     * @param num a String
     * @return boolean
     */
    public static boolean isNumeric(String num){
        AtomicBoolean isFound = new AtomicBoolean(false);

        if(NumberUtils.isCreatable(num))
            isFound.set(true);

        return isFound.get();
    }

    /**
     * Check is valid Account
     * @param user Client ID
     * @param id Account ID
     * @param accounts List of Accounts
     * @return boolean
     */
    public static boolean isAccount(String user,String id, HashMap<String,Account> accounts) {
        AtomicBoolean isFound = new AtomicBoolean(false);

        if(accounts.containsKey(id)) {
            if(accounts.get(id).getAccountHolderId().equalsIgnoreCase(user)) {
                isFound.set(true);
            }

        }
        return isFound.get();
    }
}
