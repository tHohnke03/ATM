/**
 * This module contains Utilities specific to this project
 * <p>
 * This module has Utilities specific to this project
 * Including reading and Writing to the filesystem
 * </p>
 *
 * @since 0.1
 * @author sheard
 * @version 1.0
 */
package au.com.nuvento.atm.utils;