package au.com.nuvento.atm.accounts;

/**
 * A enum for Account Types
 */
public enum AccountType {
    SAVING,
    CHEQUE;
}
