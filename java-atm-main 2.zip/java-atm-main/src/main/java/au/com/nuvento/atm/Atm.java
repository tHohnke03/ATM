package au.com.nuvento.atm;

import au.com.nuvento.atm.accounts.Account;
import au.com.nuvento.atm.models.Client;
import au.com.nuvento.atm.models.ClientInteraction;
import au.com.nuvento.atm.utils.ReadFiles;
import au.com.nuvento.atm.utils.SetupAccounts;
import au.com.nuvento.atm.utils.SetupUsers;
import au.com.nuvento.atm.utils.WriteFiles;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;

/**
 * This class is the 'Driver' class for ATM
 * @author David Sheard
 * @version 1.0
 */
public class Atm {

    static ClientInteraction clientInterface = new ClientInteraction();
    public static HashMap<String,Client> clients = new HashMap<String,Client>();
    public static HashMap<String,Account> accounts = new HashMap<String,Account>();
    public static Config conf = ConfigFactory.load();

    /**
     * Main Method
     * @param args Arguments passed to main
     * @throws FileNotFoundException Thrown if file not in path
     */
    public static void main(String[] args) throws FileNotFoundException {
        setup();
        clientInterface.run(clients,accounts);
        WriteFiles.writeFiles(accounts, conf.getString("ACCOUNT_DATA"),conf.getString("HEADER"));
    }

    /**
     * Method to set up the project
     * Reads files and add to Lists for reuse
     * @throws FileNotFoundException Thrown if file not in path
     */
    public static void setup() throws FileNotFoundException {
        ReadFiles readFiles = new ReadFiles();

        List<String[]> accountData = readFiles.getCSVFileContents(conf.getString("ACCOUNT_DATA"),
                conf.getString("ACCOUNT_DATA_DELIM"), true);
        List<String[]> userInfo = readFiles.getCSVFileContents(conf.getString("USER_INFO")
                ,conf.getString("USER_INFO_DELIM") , true);
        SetupUsers setupUsers = new SetupUsers();
        clients = setupUsers.createUsers(userInfo);
        SetupAccounts setupAccounts = new SetupAccounts();
        accounts = setupAccounts.createAccounts(accountData);
    }

}
